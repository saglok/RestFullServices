package com.eclipse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.eclipse.binding.Student;
import com.eclipse.entity.Courses;
import com.eclipse.entity.Genders;
import com.eclipse.entity.StudentEntity;
import com.eclipse.entity.Timings;
import com.eclipse.service.ServiceI;

@Controller
public class RegistrationController {
	private ServiceI serviceI;
	
	@Autowired
	public RegistrationController(ServiceI serviceI) {
		super();
		this.serviceI = serviceI;
	}
    @RequestMapping("/getAllData")
	public String getAllFormData(Model model) {
		List<String> courses = serviceI.getCourseDetails();
		//System.out.println(list);
		List<String> genders = serviceI.getGenderDetails();
		//System.out.println(list2);
		List<String> timings = serviceI.getTimingDetails();
		//System.out.println(list3);
		model.addAttribute("courses", courses);
		model.addAttribute("genders",genders);
		model.addAttribute("timings",timings);
		model.addAttribute("student",new Student());
		return "studentReg";
	}
    @PostMapping("/saveStudent")
    public String saveStudent(Student student) {
    	System.out.println(student);
    	boolean b=serviceI.saveStudent(student);
		return "registration";
    }
    @RequestMapping("/login")
	public String userLogin() {
		return "login";
	}

	@PostMapping("/log")
	public String loginCheck(StudentEntity user) {
		System.out.println("user login data:" + user);
		StudentEntity user1 = serviceI.loginCheck(user);
		if (user1 != null)
			return "loginSuccess";
		else {
			return "loginFailed";
		}
	}
}
