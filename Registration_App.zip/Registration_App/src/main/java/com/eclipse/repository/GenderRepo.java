package com.eclipse.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eclipse.entity.Genders;
@Repository
public interface GenderRepo extends CrudRepository<Genders,Integer>{

}
