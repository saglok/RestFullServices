package com.eclipse.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eclipse.entity.Timings;

@Repository
public interface TimingRepo extends CrudRepository<Timings, Integer> {

}
