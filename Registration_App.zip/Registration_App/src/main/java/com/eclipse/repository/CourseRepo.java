package com.eclipse.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eclipse.entity.Courses;
@Repository
public interface CourseRepo extends CrudRepository<Courses, Integer>{

}
