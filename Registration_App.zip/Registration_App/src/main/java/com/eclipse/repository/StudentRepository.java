package com.eclipse.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eclipse.entity.StudentEntity;
@Repository
public interface StudentRepository extends CrudRepository<StudentEntity, Integer> {

	StudentEntity save(StudentRepository studentRepo);

	StudentEntity findByNameAndEmailAndCourse(String name, String email, String course);

	}
