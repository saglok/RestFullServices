package com.eclipse.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.eclipse.binding.Student;
import com.eclipse.entity.Courses;
import com.eclipse.entity.Genders;
import com.eclipse.entity.StudentEntity;
import com.eclipse.entity.Timings;
import com.eclipse.repository.CourseRepo;
import com.eclipse.repository.GenderRepo;
import com.eclipse.repository.StudentRepository;
import com.eclipse.repository.TimingRepo;

@Service
public class ServiceImpl implements ServiceI {

	private GenderRepo genderRepo;
	private CourseRepo courseRepo;
	private TimingRepo timingRepo;
	private StudentRepository studentRepo;

	@Autowired
	public ServiceImpl(GenderRepo genderRepo, CourseRepo courseRepo, TimingRepo timingRepo,
			StudentRepository studentRepo) {
		super();
		this.genderRepo = genderRepo;
		this.courseRepo = courseRepo;
		this.timingRepo = timingRepo;
		this.studentRepo = studentRepo;
	}

	@Override
	public List<String> getGenderDetails() {
		List<Genders> genderList = (List<Genders>) genderRepo.findAll();
		List<String> genders = new ArrayList<String>();
		for (Genders G : genderList) {
			genders.add(G.getGenderName());
		}
		return genders;
	}

	@Override
	public List<String> getCourseDetails() {
		List<Courses> courseList = (List<Courses>) courseRepo.findAll();
		List<String> courses = new ArrayList<String>();
		for (Courses C : courseList) {
			courses.add(C.getCourseName());
		}
		return courses;
	}

	@Override
	public List<String> getTimingDetails() {
		List<Timings> timingList = (List<Timings>) timingRepo.findAll();
		List<String> timings = new ArrayList<String>();
		for (Timings T : timingList) {
			timings.add(T.getTimingName());
		}
		return timings;
	}

	@Override
	public boolean saveStudent(Student student) {
		StudentEntity studentEntity = new StudentEntity();
		studentEntity.setName(student.getName());
		studentEntity.setEmail(student.getEmail());
		studentEntity.setPhno(student.getPhno());
		studentEntity.setGender(student.getGender());
		studentEntity.setCourse(student.getCourse());
		studentEntity.setTimings(student.getTimings());
		StudentEntity entity = studentRepo.save(studentEntity);
		return entity != null && entity.getSid() != 0;
	}

	@Override
	public StudentEntity loginCheck(StudentEntity user) {
		String name = user.getName();
		String email = user.getEmail();
		String course = user.getCourse();
		StudentEntity user1 = studentRepo.findByNameAndEmailAndCourse(name, email, course);
		return user1;
	}
}
