package com.eclipse.service;

import java.util.List;

import com.eclipse.binding.Student;
import com.eclipse.entity.Courses;
import com.eclipse.entity.Genders;
import com.eclipse.entity.StudentEntity;
import com.eclipse.entity.Timings;

public interface ServiceI {
	public List<String> getGenderDetails();
	public List<String> getCourseDetails();
	public List<String> getTimingDetails();
	public boolean saveStudent(Student student);
	public StudentEntity loginCheck(StudentEntity user);

}
